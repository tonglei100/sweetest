恭喜你安装成功😀

现在还没有任何测试执行结果，请运行后查看

------

##### 配置方法： 

1. 请在启动脚本（如：start.py）里添加生成测试报告的代码 

    ```python
    # 执行自动化测试
    sweet.plan()

    # 生成 Web 测试报告，'D:\\report' 为 report 生成的目录    
    sweet.report(r'D:\report')
    ```

2. 执行自动化测试

3. 查看 Web 测试报告