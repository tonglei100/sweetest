from sweetest.autotest import Autotest

# 项目名称，和测试用例、页面元素表文件名称中的项目名称必须一致
project_name = 'Wechat'

# 单 sheet 页面模式
sheet_name = '音乐站'

# sheet 页面匹配模式，仅支持结尾带*
#sheet_name = 'TestCase*'

# #sheet 页面列表模式
#sheet_name = ['TestCase', 'test']

# 环境配置信息
desired_caps = {
    'platformName': 'Android', 
    'platformVersion': '6.0', 
    'deviceName': 'OPPO R9s', 
    'appPackage': 'com.tencent.mm', 
    'appActivity': '.ui.LauncherUI', 
    'noReset' : True, 
    'chromeOptions': {
        'androidProcess': 'com.tencent.mm:appbrand0'
        }
    }

# appium server
server_url = 'http://10.1.4.162:4723/wd/hub'

# 执行
test = Autotest(project_name, sheet_name, desired_caps, server_url)

test.plan()
